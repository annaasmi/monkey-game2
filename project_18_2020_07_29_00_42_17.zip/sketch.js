var monkey,backGround,bananaImage,ObstacleImage,bananaGroup,
    obstacleGroup,Monkey_running,ground,PLAY,END,gamestate,
    score,r,backImage;

function preload(){
bananaImage = loadImage("Bananas.png","Banana.png");
ObstacleImage = loadImage("stone.png");
backImage = loadImage("jungle2.jpg");
  
  bananaGroup = new Group();
  obstacleGroup = new Group();
  
  
Monkey_running = loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");  
  
}

function setup(){
 createCanvas(700,400) 
  ground = createSprite(50,380,50,10);
  ground.visible = false;
  
  monkey = createSprite(50,370,10,10);
  monkey.addAnimation("monkey", Monkey_running);
  monkey.scale = 0.1;
  //console.log(monkey.depth);
  
 // if(keyDown("space")){
  // monkey.velocityY = -12;    
  //}
  //monkey.velocityY = monkey.velocity+0.8;
  
  backGround = createSprite(200,200,400,400);
  backGround.addImage("backImage",backImage);
  backGround.velocityX = -3;
  backGround.x = backGround.width/2;
  backGround.scale = 1.2;
  backGround.depth = 0;
  
  PLAY = 1;
  END = 0;
  gamestate = PLAY;
  
  score = 0
  stroke("white");
  textSize(20);
  fill("white");
 
  r = random(190,600);
  
}

function draw(){
  background(255);
 Banana();
    obstacle();
if (backGround.x < 100){
      backGround.x = backGround.width/2;
     }
    
    
    
    if(bananaGroup.isTouching(monkey)){
       score = score+2;
      bananaGroup.destroyEach();
       }
    
    switch(score){
      case 10: monkey.scale=0.12;
        break;
        case 20: monkey.scale=0.14;
        break;
        case 30: monkey.scale=0.16;
        break;
        case 40: monkey.scale=0.18;
        break;
        default: break;
    }
    
    if(obstacleGroup.isTouching(monkey)){
     monkey.scale = 0.1; 
    }
  monkey.collide(ground);
    
 drawSprites();
  text("Score: "+ score,500,50);
}

function Banana(){
  if(World.frameCount% 80 === 0){
  var banana = createSprite(100,270,10,10);
  banana.x = r;
  banana.addImage("banana",bananaImage);
  banana.velocityX = -3;
  banana.scale = 0.015;
  banana.lifetime = 100;
  banana.depth = 2;
  bananaGroup.add(banana);
  }
  
}

function obstacle(){
  if(World.frameCount% 80 === 0){
    var stone = createSprite(100,360,10,10);
    stone.x = r;
    stone.addImage("Stone",ObstacleImage);
    stone.velocityX = -3;
    stone.scale = 0.13;
    stone.lifetime = 100;
    obstacleGroup.add(stone);
  }
}


